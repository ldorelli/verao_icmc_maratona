#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int N = 10000;

int v[N];

int main (void)
{
	int n, c;

	while (cin >> n) 
	{
		vector <int> v(n);
		for (int i = 0; i < n; ++i)
			cin >> v[i];
		sort (v.begin(), v.end());
		int unique = 0;
		for (int i = 0; i < n-1; ++i)
			if (v[i] != v[i+1]) unique++;
		printf("%d\n", unique+1);		
	}
	return 0;
}