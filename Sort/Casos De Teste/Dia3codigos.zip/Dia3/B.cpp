#include <cstdio>
#include <string>
#include <iostream>
#include <set>

using namespace std;

int main (void)
{
	string s;
	set <string> dic;
	int n, q;

	cin >> n;
	for (int i = 0; i < n; ++i) 
	{
		cin >> s;
		dic.insert(s);
	}

	cin >> q;
	for (int i = 0; i < q; ++i)
	{
		cin >> s;
		if (dic.count(s)) cout << "S\n";
		else cout << "N\n";
	}
}