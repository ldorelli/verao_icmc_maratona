#include <iostream>
#include <string.h>

using namespace std;

const int N = 1000;

string field[N];
int n, m;
int result = 0;
int used[N][N];

void solve(int i, int j) {
	if(i < 0 || i >= n || j < 0 || j >= m || used[i][j] || field[i][j] == 'o') return;

	used[i][j] = 1;

	result++;
	solve(i, j + 1);
	solve(i, j - 1);
	solve(i + 1, j);
	solve(i - 1, j);
}

int main () {
	ios::sync_with_stdio(0);
	
	while(cin >> n >> m) {
		result = 0;
		memset(used, 0, sizeof used);

		for(int i = 0; i < n; i++) 
			cin >> field[i];

		solve(0, 0);
		cout << result << "\n";
	}
	return 0;
}

