#include <cstdio>
#include <string>
#include <iostream>
#include <set>

using namespace std;

int main (void)
{
	int n, x;

	while (cin >> n) 
	{
		bool rep = false;
		set<int> S;
		for (int i = 0; i < n; ++i)
		{
			cin >> x;
			if (S.count(x)) rep = true;
			S.insert(x);
		}		
		if (rep) cout << "S\n";
		else cout << "N\n";
	}

}