#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

const int N = 10000;
int v[N], ac[N];
int n, t;

int solve (int i)
{
	int sub = 0;
	if (i) sub = ac[i-1];
	int p = upper_bound(ac + i, ac + n, t + sub) - ac;
	return p-i;
}

int main(void)
{
	while(cin >> n >> t)
	{
		for (int i = 0; i < n; ++i)
			cin >> v[i];

		ac[0] = v[0];
		for (int i = 1; i < n; ++i)
			ac[i] = ac[i-1] + v[i];

		int ans = 0;
		for (int i = 0; i < n; ++i)
		{
			ans = max(ans, solve(i));
		}
		cout << ans << endl;
	}
	return 0;
}