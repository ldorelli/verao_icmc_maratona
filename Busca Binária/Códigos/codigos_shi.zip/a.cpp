#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

const int N = 20000;
int np[N];
vector<int> primos;


void pre()
{
	for (int x = 2; x < N; ++x)
		if(!np[x]) 
		{
			for (int y = x*x; y < N; y += x)
				np[y] = 1;
		}
	for (int x = 2; x < N; ++x) 
		if(!np[x]) primos.push_back(x);
}

int main(void)
{
	pre();
	int Y;
	while(cin >> Y)
	{
		int x = lower_bound(primos.begin(), primos.end(), Y) - primos.begin();
		cout << primos[x] << endl;
	}
	return 0;
}