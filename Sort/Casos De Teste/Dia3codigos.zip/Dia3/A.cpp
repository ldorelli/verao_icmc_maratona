#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int main (void)
{
	string s;
	while ( getline(cin, s) )
	{
		if (s == "mamao com acucar") 
		{
			return 0;
		}
		cout << s << endl;
	}
}