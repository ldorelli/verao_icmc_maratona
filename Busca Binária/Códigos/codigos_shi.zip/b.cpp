#include <iostream>
#include <cstdio>
#include <vector>
#include <string>

using namespace std;

bool equal(string &a, string &b)
{
	int cntA[26] = {0};
	int cntB[26] = {0};

	for (int i = 0; i < a.size(); ++i) cntA[a[i]-'a']++;
	for (int i = 0; i < b.size(); ++i) cntB[b[i]-'a']++;
	for (int i = 0; i < 26; ++i) if(cntA[i] != cntB[i]) return false;
	
	return true;
}

int main(void)
{
	int n;
	while(cin >> n)
	{
		vector<string> v(n);
	
		for (int i = 0; i < n; ++i) cin >> v[i];
	
		int res = 0;
		for (int i = 0; i < n; ++i)
		{
			bool ok = true;
			for (int j = 0; j < i; ++j) 
				if(equal(v[i], v[j])) ok = false;
			if(ok) ++res;
		}
	
		cout << res << endl;
	}
	return 0;
}