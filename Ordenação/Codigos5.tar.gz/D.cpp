#include <iostream>
#include <algorithm>

using namespace std;

int d[100000];
int c[100000];

int main()
{
	cin.sync_with_stdio(false);
	int n, m;
	while (cin >> n >> m)
	{
		for (int i = 0; i < n; ++i)
			cin >> d[i];
		for (int i = 0; i < m; ++i)
			cin >> c[i];
			
		sort(d, d+n, greater<int>());
		sort(c, c+m, greater<int>());
		
		bool ok = true;
	
		for (int i = 0; i < n; ++i)
		{
			if (d[i] >= c[i])
				ok = false;
		}
		cout << (ok ? "S" : "N") << "\n";
	}
	return 0;
}
