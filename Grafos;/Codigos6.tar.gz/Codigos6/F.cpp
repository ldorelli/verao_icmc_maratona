#include <iostream>
#include <vector>
using namespace std;

const int N = 1001, M = 3000;

int n, m, vis[N];
vector<int> adj[N], id[N];

void dfs(int p, int g)
{
	vis[p] = 1;
	for (int i = 0; i < adj[p].size(); ++i)
	{
		int q = adj[p][i];
		int h = id[p][i];
		if (vis[q] || h == g) continue;
		dfs(q, g);
	}
}

int main()
{
	ios::sync_with_stdio(0);
	
	while (cin >> n >> m)
	{
		// limpa e le a entrada
		for (int i = 1; i <= n; ++i)
			adj[i].clear(), id[i].clear();
		
		for (int i = 0; i < m; ++i)
		{
			int a, b;
			cin >> a >> b;
			adj[a].push_back(b);
			adj[b].push_back(a);
			id[a].push_back(i);
			id[b].push_back(i);
		}
		
		int res = 1;
		// testa tirar aresta por aresta
		for (int i = 0; i < m && res; ++i)
		{
			// rodar a dfs do vertice 1
			for (int j = 1; j <= n; ++j)
				vis[j] = 0;
			dfs(1, i);
			
			if (!vis[n]) res = 0;
		}
		
		if (res) cout << "S\n";
		else cout << "N\n";
	}
	
}

