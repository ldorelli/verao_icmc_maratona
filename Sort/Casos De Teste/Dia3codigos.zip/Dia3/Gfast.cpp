#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int N = 100000;

int v[N];

int main (void)
{
	int n;

	while (cin >> n) 
	{
		int lo, hi;
		for (int i = 0; i < n; ++i) cin >> v[i];
		lo = hi = 0;
		for (int i = 1; i < n; ++i)
		{
			if (v[i] > v[hi]) hi = i;
			if (v[i] < v[lo]) lo = i;
		}
		cout << (v[lo] - v[hi]) << endl;
	}
	return 0;
}