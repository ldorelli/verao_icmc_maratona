#include <cstdio>
#include <string>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main (void)
{
	int n, x;

	while (cin >> n) 
	{
		bool rep = false;
		vector <int>  v (n);
		for (int i = 0; i < n; ++i)
			cin >> v[i];

		sort(v.begin(), v.end());
		for (int i = 0; i < n-1; ++i)
			if (v[i] == v[i+1]) rep = true;

		if (rep) cout << "S\n";
		else cout << "N\n";
	}

}