#include <cstdio>

int main()
{
	int n, k, d;
	while(scanf("%d%d%d",&n,&k,&d) != EOF)
	{
		int c = 0;
		for (int i = 0; i < n; ++i)
		{
			int m;
			scanf("%d", &m);
			if (c < d) 
				printf("%d\n",m);
			c = (c+1)%k;
		}
	}
	return 0;
}
