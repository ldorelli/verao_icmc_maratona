#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <queue>
#include <string>

using namespace std;

int main () {

	string a, b;
	
	while(cin >> a >> b) 
	{
		cout << a + b << endl;
	}
	
	return 0;
}
