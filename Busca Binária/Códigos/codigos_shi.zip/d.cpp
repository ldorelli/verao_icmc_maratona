#include <iostream>
#include <cstdio>
#include <vector>
#include <string>

using namespace std;

const int N = 10001;
vector<int> g[N], w[N];
int vis[N];
int n, m;

void dfs (int v, int t)
{
	vis[v] = 1;
	for (int i = 0; i < g[v].size(); ++i)
	{
		if (vis[g[v][i]]) continue;
		if (w[v][i] <= t) dfs (g[v][i], t);
	}
}

bool test (int t)
{
	memset (vis, 0, sizeof vis);
	dfs (1, t);
	return vis[n];
}

int main(void)
{
	while(cin >> n >> m)
	{
		for (int i = 1; i <= n; ++i) g[i].clear(), w[i].clear();
		for(int i = 0; i < m; ++i)
		{
			int a, b, c
			cin >> a >> b >> c;
			g[a].push_back(b);
			w[a].push_back(c);
			g[b].push_back(a);
			w[b].push_back(c);
		}
		int lo = 0, hi = 1000000000;
		while (lo != hi) 
		{
			int mid = (hi + lo)/2;
			if (test(mid)) hi = mid;
			else lo = mid + 1;
		}
		cout << lo << endl;
	}
	return 0;
}