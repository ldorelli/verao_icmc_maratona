#include <cstdio>
#include <string>
#include <iostream>
#include <map>

using namespace std;

const int N = 10000;

int v[N];

int main (void)
{
	int n, c;

	while (cin >> n) 
	{
		map<int, int> m;
		bool res = false;

		for (int i = 0; i < n; ++i)
		{
			cin >> v[i];
			m[v[i]]++;
		}		

		cin >> c;		
		for (int i = 0; i < n; ++i)
		{
			int must = 0;
			if (c-v[i] == v[i]) must = 1;
			if (m[c-v[i]] > must) res = true;
		}

		if (res) printf("S\n");
		else printf("N\n");
	}

}