#include <iostream>
#include <iostream>
#include <string>
#include <cstring>
using namespace std;

const int N = 1000;
string field[N];

int n, m;
int used[N][N];

bool solve(int i, int j) {
	if(i < 0 || i >= n || j < 0 || j >= m) return false;

	if(used[i][j] == 1) return true;
	if(used[i][j] == 2) return false;
	used[i][j] = 1;

	if(field[i][j] == '>' || field[i][j] == '#')  {
		if(solve(i, j + 1)) return true;
	}

	if(field[i][j] == '<' || field[i][j] == '#') {
		if(solve(i, j - 1)) return true;
	}
	if(field[i][j] == '^' || field[i][j] == '#') {
		if(solve(i - 1, j)) return true;
	}

	if(field[i][j] == 'v' || field[i][j] == '#') {
		if(solve(i + 1, j)) return true;
	}
	
	used[i][j] = 2;
	
	return false;
}

int main () {
	ios::sync_with_stdio(0);
	
	while(cin >> n >> m) {
		memset(used, 0, sizeof used);
		for(int i = 0; i < n; i++) 
			cin >> field[i];
		cout << (solve(0, 0) ? "S\n" : "N\n");
	}
	return 0;
}

