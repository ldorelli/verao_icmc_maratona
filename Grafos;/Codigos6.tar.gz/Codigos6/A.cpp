#include <iostream>
#include <map>

using namespace std;

int main () {
	ios::sync_with_stdio(0);
	
	map<int,int> m;
	int n, a, b;
	while(cin >> n) {
		while(n--) {
			cin >> a >> b;
			m[a]++;
			m[b]++;
		}

		for(map<int, int>::iterator it = m.begin(); it != m.end(); ++it)
			cout << (*it).first << " " << (*it).second << '\n';
		cout << "*\n";
		m.clear();
	}
	return 0;
}
