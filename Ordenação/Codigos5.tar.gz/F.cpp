#include <iostream>
#include <algorithm>
using namespace std;

const int N = 100000;

int n, d;

int main()
{
	ios::sync_with_stdio(0);
	
	while (cin >> n >> d)
	{
		int res = 0;
		for (int i = 0; i < n; ++i)
		{
			int pos, dir;
			cin >> pos >> dir;
			
			if (dir == 1) res = max(res, pos);
			else res = max(res, d-pos);
		}
		
		cout << res << '\n';
	}
}

