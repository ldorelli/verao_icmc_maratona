#include <iostream>
#include <queue>

using namespace std;

int main()
{
	cin.sync_with_stdio(false);
	int n, m;
	while (cin >> n >> m)
	{
		priority_queue<int> a, b;
		for (int i = 0; i < n; ++i)
		{
			int v;
			cin >> v;
			a.push(v);
		}
		for (int i = 0; i < m; ++i)
		{
			int v;
			cin >> v;
			b.push(v);
		}
		while (!a.empty() && !b.empty())
		{
			int aa = a.top(); a.pop();
			int bb = b.top(); b.pop();
			if (aa > bb)
				a.push(aa-bb);
			else if (bb > aa)
				b.push(bb-aa);
		}
		cout << a.size() << " " << b.size() << "\n";
	}
	return 0;
}
