#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int N = 100000;

int v[N];

int main (void)
{
	int n;

	while (cin >> n) 
	{
		for (int i = 0; i < n; ++i) cin >> v[i];
		sort (v, v+n);
		long long res = 0;
		for (int i = 0; i < n-1; ++i)
			res += (v[i]-v[i+1]);
		cout << res << endl;
	}
	return 0;
}